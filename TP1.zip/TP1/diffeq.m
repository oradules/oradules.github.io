function dx=diffeq(t,x,k)
 	 %------ the actual equations  
     cell=1;
 	 dx=[ 
	 	 ((cell*k(1)*k(78)*power(k(3), k(4)))/(power(k(3), k(4)) + power(x(16), k(4))))*x(13) + (cell*(k(2)*k(78) + (k(5)*power(x(9), k(6)))/(power(k(7), k(6)) + power(x(9), k(6))))*power(k(3), k(4)))/(power(k(3), k(4)) + power(x(16), k(4))) - cell*function_1(k(8), x(1), k(9));
	 	 cell*k(10)*x(1) - cell*function_1(k(13), x(2), k(14)) - cell*k(11)*x(2) + cell*k(12)*x(3);
	 	 cell*k(11)*x(2) - cell*function_1(k(15), x(3), k(16)) - cell*k(12)*x(3);
	 	 (cell*k(17)*power(k(20), k(21))*power(x(12), k(18)))/((power(k(20), k(21)) + power(x(3), k(21)))*(power(k(19), k(18)) + power(x(12), k(18)))) - cell*function_1(k(22), x(4), k(23));
	 	 (cell*k(24)*k(29)*x(4) - cell*k(25)*x(5)^2 - x(5)*(cell*k(27) + cell*k(28) + cell*k(25)*k(29) - cell*k(27)*k(78)) + cell*k(26)*k(29)*x(6) + cell*k(24)*x(4)*x(5) + cell*k(26)*x(5)*x(6))/(k(29) + x(5));
	 	 -(x(6)*(cell*k(30) + cell*k(31) + cell*k(26)*k(32) - cell*k(30)*k(78)) + cell*k(26)*x(6)^2 - cell*k(25)*k(32)*x(5) - cell*k(25)*x(5)*x(6))/(k(32) + x(6));
	 	 (cell*(k(33)*k(37)*power(x(6), k(34)) - k(36)*x(7)*power(k(35), k(34)) + k(33)*x(7)*power(x(6), k(34)) - k(36)*x(7)*power(x(6), k(34))))/((k(37) + x(7))*(power(k(35), k(34)) + power(x(6), k(34))));
	 	 cell*k(38)*x(7) - cell*function_1(k(41), x(8), k(42)) - cell*k(39)*x(8) + cell*k(40)*x(9);
	 	 cell*k(39)*x(8) - cell*function_1(k(43), x(9), k(44)) - cell*k(40)*x(9);
	 	 ((cell*k(45)*k(78)*power(k(48), k(50))*power(k(49), k(51)) + cell*k(45)*k(78)*power(k(49), k(51))*power(x(6), k(50)))*x(10)*x(13) + (cell*k(47)*power(k(48), k(50))*power(k(49), k(51)) - cell*k(52)*power(k(48), k(50))*power(k(49), k(51)) - cell*k(52)*power(k(48), k(50))*power(x(3), k(51)) - cell*k(52)*power(k(49), k(51))*power(x(6), k(50)) - cell*k(52)*power(x(3), k(51))*power(x(6), k(50)) + cell*k(46)*k(78)*power(k(48), k(50))*power(k(49), k(51)))*x(10) + (cell*k(45)*k(53)*k(78)*power(k(48), k(50))*power(k(49), k(51)) + cell*k(45)*k(53)*k(78)*power(k(49), k(51))*power(x(6), k(50)))*x(13) + cell*k(47)*k(53)*power(k(48), k(50))*power(k(49), k(51)) + cell*k(46)*k(53)*k(78)*power(k(48), k(50))*power(k(49), k(51)))/(k(53)*power(k(48), k(50))*power(k(49), k(51)) + k(53)*power(k(48), k(50))*power(x(3), k(51)) + x(10)*power(k(48), k(50))*power(k(49), k(51)) + k(53)*power(k(49), k(51))*power(x(6), k(50)) + x(10)*power(k(48), k(50))*power(x(3), k(51)) + k(53)*power(x(3), k(51))*power(x(6), k(50)) + x(10)*power(k(49), k(51))*power(x(6), k(50)) + x(10)*power(x(3), k(51))*power(x(6), k(50)));
	 	 cell*k(54)*x(10) - cell*function_1(k(57), x(11), k(58)) - cell*k(55)*x(11) + cell*k(56)*x(12);
	 	 cell*k(55)*x(11) - cell*function_1(k(59), x(12), k(60)) - cell*k(56)*x(12);
	 	 ((-cell*k(64)*k(78))*x(13)^2 + (cell*k(61) - cell*k(63) - cell*k(61)*k(78) - cell*k(62)*k(64)*k(78))*x(13) + cell*k(61)*k(62) - cell*k(61)*k(62)*k(78))/(x(13) + k(62));
	 	 (x(13)*(cell*k(65)*k(70)*k(78)*power(k(68), k(66)) + cell*k(65)*k(70)*k(78)*power(x(3), k(66))) - x(14)*(cell*k(69)*power(k(68), k(66)) - cell*k(67)*power(x(3), k(66)) + cell*k(69)*power(x(3), k(66))) + x(13)*x(14)*(cell*k(65)*k(78)*power(k(68), k(66)) + cell*k(65)*k(78)*power(x(3), k(66))) + cell*k(67)*k(70)*power(x(3), k(66)))/(k(70)*power(k(68), k(66)) + k(70)*power(x(3), k(66)) + x(14)*(power(k(68), k(66)) + power(x(3), k(66))));
	 	 cell*k(71)*x(14) - cell*function_1(k(74), x(15), k(75)) - cell*k(72)*x(15) + cell*k(73)*x(16);
	 	 cell*k(72)*x(15) - cell*function_1(k(76), x(16), k(77)) - cell*k(73)*x(16);
	 ];
    function p=power(a,b)
        p=a^b;
    end
    function p1=function_1(a,b,c)
        p1=a*b/(b+c);
    end
 end 
