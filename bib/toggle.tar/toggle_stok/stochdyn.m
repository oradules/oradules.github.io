function traj=stochdyn(etat,t0,tmax,nmax,nstore);
global m n_reactions n_produits;
%   --- Solveur stochastique
rand('state',sum(100*clock)); %% intialiser generateur no aleatoires
time=t0;
n_react=0;
while time < tmax & n_react < nmax
    preact=reaction_sto(etat); %%% reactions / unite de temps
    preact_rev=reaction_reverse_sto(etat); %%% reactions reverse / unite de temps
    tot=sum(preact)+sum(preact_rev);
    aa=cat(1,preact,preact_rev); %%% concatener les taux, mettre les reactions inverses dans 2-eme partie
    if tot>0.0
        tau=-log(rand(1))/tot; %%% temps entre reactions
        %%%% choix reaction
        u=rand(1);
        cum=0;
        i=0;
        while cum<u
            i=i+1;
            cum=cum+aa(i)/tot;
        end %%% choix reaction   
        if i>n_reactions
            signe=-1;
            i=i-n_reactions;
        else
            signe=1;
        end; 
            time=time+tau; %%% incrementer temps
            n_react=n_react+1;
            etat=etat + transpose(signe*m(:,i)); %%%% changer etat
         	
         
            tetat=cat(2,time,etat);
            if n_react==1 
               traj=tetat;
              % tetat_moy=tetat*nstore;
            else

					if mod(n_react-1,nstore)==0
   						traj=cat(1,traj,tetat);
                  	%traj=cat(1,traj,tetat_moy/nstore);
                                    %tetat_moy=tetat;
               end  
               %tetat_moy=tetat_moy+tetat;                  
            end      
    else
            time=tmax;
    end         
end % while                     
     
   
