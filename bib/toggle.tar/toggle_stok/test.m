fid=fopen('ab1.txt');
nhead=10;


for i=1:nhead
   line=fgetl(fid);
   disp(line);
end;
close(fid)