global m k1 k2 k3 k4 k5 km1 km2 km3 nu n_reactions volume;

n_produits=5;
n_reactions=5;
% parametres stoechiometriques
nu=2;n=5;
%%%%%%%%%%%%%%%%%%%%%%%
% parametres cin�tiques
%%%%%%%%%%%%%%%%%%%%%%%
%%% fixe echelle parametre d'ordre X=amp et 0 aux attracteurs
amp=1;
chi1=1/amp;
chi2=chi1;
alpha=3;
chi3=chi2;
%%% fixe echelle parametre d'orde D
D0=amp/4;

volume=10/D0   ; %%% choisir un volume (ici pour avoir un seul site promoteur/cellule)
% fixer des echelles de temps
k1=0.1; %formation heterodimere
k2=0.1; %adhesion site
k3=0.1; %blockage
k5=0.01; %degradation
km1=k1/chi1;
km2=k2/chi2;
km3=k3/chi3;
k4=k5*alpha/(n*D0); %% K4,k5 a peu pres meme ordre de gradeur
%%%%%%%%%%%%%%%%%%%%%%%%
m=zeros(n_produits,n_reactions);
%matrice stoechiometrique
m=[-nu,1,0,0,0;0,-1,-1,1,0;0,-1,0,-1,1;n,0,0,0,0;-1,0,0,0,0]';
%   --- Condition initiale
x0=zeros(1,n_produits); %Initial condition set to zero for each molecule
x0(1)=2*amp; % facteur transcription initial
x0(1)=amp;
x0(3)=D0; % sites promoteurs initials
t0=0;
tmax=5000;
%   --- Solveur deterministe
[T,X]=ode23tb('deterministe',[t0, tmax],x0);



% Visualiser solution
figure(1)
hold off
subplot(2,2,1)
hold off;
plot(T,X(:,1)); hold on;
grid on;
xlabel('temps');
ylabel('X');
subplot(2,2,2)
hold off;
plot(T,X(:,2));hold on;
grid on;
xlabel('temps');
ylabel('X_\nu');
subplot(2,2,3)
hold off;
plot(T,X(:,3));hold on;
grid on;
xlabel('temps');
ylabel('D');
subplot(2,2,4)
hold off;
plot(T,X(:,4));hold on;
grid on;
xlabel('temps');
ylabel('D_1');


% visualiser vari�t� lente
figure(2)
subplot(2,1,1)
x=0:0.01:1.0; d= 1./(1 + x.^2 + x.^4);
hold off;
plot(x,d,'r','Linewidth',2);hold on;
plot(X(:,1)/amp,X(:,3)/D0);
xlabel('X/A');ylabel('D/D_0');

subplot(2,1,2)
x=0:0.01:1.0; d= x.^2./(1 + x.^2 + x.^4);
hold off;
plot(x,d,'r','Linewidth',2);hold on;
plot(X(:,1)/amp,X(:,4)/D0);
xlabel('X/A');ylabel('D_1/D_0');

etat=x0*volume;
nmax=10000;
nstore=1;
traj=stochdyn(etat,t0,tmax,nmax,nstore);



figure(1)         
        subplot(2,2,1);
        plot(traj(:,1),traj(:,2)/volume,'.');
        subplot(2,2,2);
        plot(traj(:,1),traj(:,3)/volume,'.');
        subplot(2,2,3);
        plot(traj(:,1),traj(:,4)/volume,'.');
        subplot(2,2,4);
        plot(traj(:,1),traj(:,5)/volume,'.');
                
        figure(2)
        subplot(2,1,1);
        plot(traj(:,2)/volume/amp,traj(:,4)/volume/D0,'.');
        subplot(2,1,2);
        plot(traj(:,2)/volume/amp,traj(:,5)/volume/D0,'.');
       
return


