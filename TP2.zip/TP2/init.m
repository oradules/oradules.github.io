function [x0,k,names,parnames]=init 
    x0=[ 0.1,  1,  4]; 
    k=[10,68,1,0.15,0,4.422,1,0.06,10,10,0.0005,1,1,0.1,68,20,30,10,1,1000,3];  
    names={'HMP','Fru16P2','ATP'};
    parnames= {'GLU', 'VHK', 'KGlc', 'KATP1', 'wild_type', 'KiTre6P', 'KR_HMP', 'KR_ATP', 'Ki_ATP', 'ci', 'c1', 'c2', 'KFru16P2', 'KADP', 'VATPase', ...
     'Vlower', 'VPFK', 'gR', 'gT', 'L0', 'KATP2'};
end 