function dx=diffeq(t,x,k)
    GLU = k(1);
    VHK = k(2);
    KGlc = k(3);
    KATP1 = k(4);
    wild_type = k(5);
    KiTre6P = k(6);
    KR_HMP = k(7);
    KR_ATP = k(8);
    Ki_ATP = k(9);
    ci = k(10);
    c1 = k(11);
    c2 = k(12);
    KFru16P2 = k(13);
    KADP = k(14);
    VATPase = k(15);
    Vlower = k(16);
    VPFK = k(17);
    gR = k(18);
    gT = k(19);
    L0 = k(20);
    KATP2 = k(21);
    S= [1 -1 0 0;0 1 -1 0;-1 -1 4 -1];
    Tre6P=(x(1))^2 ;  
    R1=((VHK*GLU*x(3))/(KGlc*KATP1))/((1+GLU/KGlc+wild_type*Tre6P/KiTre6P)*(1+x(3)/KATP1)); 
    lambda1=x(1)/KR_HMP;
    lambda2=x(3)/KR_ATP;
    lambda3=x(3)/Ki_ATP;
    R=1+lambda1+lambda2+gR*lambda1*lambda2;
    T=1+c1*lambda1+c2*lambda2+gT*c1*lambda1*c2*lambda2;    
    L=L0*((1+ci*lambda3)/(1+lambda3))^2;
         
    R2=(VPFK*gR*lambda1*lambda2*R)/(R^2+L*T^2);
    R3=((Vlower*x(2)*(5-x(3)))/(KFru16P2*KADP))/((1+x(2)/KFru16P2)*(1+(5-x(3))/KADP));
    R4=VATPase*x(3)/(KATP2+x(3));
    dx=S *[R1;R2;R3;R4];
end

